﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

namespace Assignment1
{
    public partial class RecoverPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Submit_btn_Click(object sender, EventArgs e)
        {
            string email = Email_txb.Text;
            SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Management_Software.mdf;Integrated Security=True");
            String getUser = "SELECT * FROM [User] WHERE Email='" + email + "'";
            connect.Open();
            SqlDataAdapter da = new SqlDataAdapter(getUser, connect);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count < 1) {
                StatusMessage_lbl.ForeColor = System.Drawing.Color.Red;
                StatusMessage_lbl.Text = "Mail could not be found";
                return;
            }
            StringBuilder newPass = new StringBuilder();
            Random rand = new Random();
            int temp;
            char c;
            for (int x = 0; x < 8; x++) {
                temp = Convert.ToInt32(rand.Next(48,122));
                while ((temp > 57 && temp < 65) || (temp > 90 && temp < 97)) {
                    temp = Convert.ToInt32(rand.Next(48, 122));
                }
                c = Convert.ToChar(temp);
                newPass.Append(c);
            }
            String insertPass = "UPDATE [User] SET Password ='" + newPass + "' WHERE Id='"+dt.Rows[0][0]+"'";
            SqlCommand command = new SqlCommand(insertPass, connect);
            da = new SqlDataAdapter();
            da.UpdateCommand = new SqlCommand(insertPass, connect);
            da.UpdateCommand.ExecuteNonQuery();
            command.Dispose();
            connect.Close();

            try
            {
                StringBuilder mailBody = new StringBuilder();
                mailBody.Append("Dear " + dt.Rows[0][1] + ",<br/><br/>");
                mailBody.Append("Your new Password is " + newPass);
                mailBody.Append("<br/>");
                mailBody.Append("You can change your password in the profile section of your page.");
                mailBody.Append("<br/><br/>");
                mailBody.Append("Regards,<br/>");
                mailBody.Append("<b>TechKnow Pro<b>");

                SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
                client.EnableSsl = true;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new NetworkCredential("techknowpro123@gmail.com", "tech123*");
                MailMessage mail = new MailMessage();
                mail.IsBodyHtml = true;
                mail.To.Add(email);
                mail.From = new MailAddress("techknowpro123@gmail.com");
                mail.Subject = "Password Recovery";
                mail.Body = Convert.ToString(mailBody);
                client.Send(mail);
                StatusMessage_lbl.ForeColor = System.Drawing.Color.Green;
                StatusMessage_lbl.Text = "Mail sent succesfully";
            }
            catch (Exception ex) {
                StatusMessage_lbl.ForeColor = System.Drawing.Color.Red;
                StatusMessage_lbl.Text = "Mail could not be send";
            }
            

          
        }
    }
}   