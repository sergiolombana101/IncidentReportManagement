﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;

namespace Assignment1
{
    public partial class Customer : System.Web.UI.Page
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Management_Software.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (Session["User"] == null)
            {
                Response.Redirect("login.aspx?login=false");
            }
            if (!IsPostBack)
            {
               
                connect.Open();
                String getCust = "SELECT Id, First_Name, Last_Name, Address, Email, Phone_Number FROM [User] WHERE Role ='"+"client"+"'";
                SqlDataAdapter da = new SqlDataAdapter(getCust, connect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int x = 0; x < dt.Rows.Count; x++)
                    {
                        string firstName = Convert.ToString(dt.Rows[x][1]);
                        string secondName = Convert.ToString(dt.Rows[x][2]);
                        string fullname = secondName.Replace(" ", "") + ", " + firstName.Replace(" ", "");
                        ListItem list = new ListItem(fullname, Convert.ToString(dt.Rows[x][0]));
                        Customer_DropList.Items.Insert(x, list);
                    }
                    string addressTemp = Convert.ToString(dt.Rows[0][3]);
                    string[] address = addressTemp.Split('-');
                    string phone = "Not provided";
                    if (Convert.ToString(dt.Rows[0][5]) != "")
                    {
                        phone = Convert.ToString(dt.Rows[0][5]);
                    }
                    string email = Convert.ToString(dt.Rows[0][4]);
                    StreetAdd_lbl.Text = address[0].Replace("  ", "");
                    Phone_lbl.Text = phone;
                    Email_lbl.Text = email;
                    connect.Close();

                }
            }
        }

        protected void Customer_DropList_SelectedIndexChanged(object sender, EventArgs e)
        {
            Error_Message.Visible = false;
            int custId = Convert.ToInt32(Customer_DropList.SelectedValue);
            connect.Open();
            String getCust = "SELECT Address, Phone_Number, Email FROM [User] WHERE Id='" + custId + "'";
            SqlDataAdapter da = new SqlDataAdapter(getCust, connect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0) {
                string addressTemp = Convert.ToString(dt.Rows[0][0]);
                string[] address = addressTemp.Split('-');
                string phone = "Not provided";
                if (Convert.ToString(dt.Rows[0][1]) != "")
                {
                    phone = Convert.ToString(dt.Rows[0][1]);
                }
                string email = Convert.ToString(dt.Rows[0][2]);
                StreetAdd_lbl.Text = address[0].Replace("  ", "");
                Phone_lbl.Text = phone;
                Email_lbl.Text = email;
            }
            connect.Close();

        }

        protected void AddCL_btn_Click(object sender, EventArgs e)
        {
            int custId = Convert.ToInt32(Customer_DropList.SelectedValue);
            connect.Open();
            String getCust = "SELECT First_Name, Last_Name, Phone_Number, Email FROM [User] WHERE Id='" + custId + "'";
            SqlDataAdapter da = new SqlDataAdapter(getCust, connect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0) {
                string firstN = Convert.ToString(dt.Rows[0][0]);
                string lastN = Convert.ToString(dt.Rows[0][1]);
                string phone = "Phone number not provided";
                if (Convert.ToString(dt.Rows[0][2]) != "")
                {
                    phone = Convert.ToString(dt.Rows[0][2]);
                }
                string email = Convert.ToString(dt.Rows[0][3]);
                String getUsers = "SELECT * FROM [Contact_List] WHERE Cust_Id='" + custId + "'";
                da = new SqlDataAdapter(getUsers, connect);
                dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0) {
                    Error_Message.Text = "User is already in the contact list!";
                    Error_Message.ForeColor = System.Drawing.Color.Red;
                    Error_Message.Visible = true;
                    connect.Close();
                    return;
                }

                String insertCL = "INSERT INTO [Contact_List]" +
                                "(Cust_id, First_Name, Last_Name, Phone_Number, Email)" +
                                "VALUES('" + custId + "','" + firstN.Replace(" ","")+ "','" + lastN.Replace(" ","") + "','" + phone + "','" + email.Replace(" ","") + "')";
                SqlCommand command = new SqlCommand(insertCL, connect);
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.InsertCommand = new SqlCommand(insertCL, connect);
                adapter.InsertCommand.ExecuteNonQuery();

                command.Dispose();
                connect.Close();

                Error_Message.Text = "Customer succesfully added to Contact List";
                Error_Message.ForeColor = System.Drawing.Color.Green;
                Error_Message.Visible = true;

            }
        }

        protected void DisplayCL_btn_Click(object sender, EventArgs e)
        {
            Response.Redirect("ContactList.aspx");
        }

        protected void LogOut_btn_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("login.aspx?logOut=true");
        }
    }
}