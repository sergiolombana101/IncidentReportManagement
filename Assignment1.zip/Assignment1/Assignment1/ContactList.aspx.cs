﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;

namespace Assignment1
{
    public partial class ContactList : System.Web.UI.Page
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Management_Software.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (Session["User"] == null)
            {
                Response.Redirect("login.aspx?login=false");
            }
            if (!IsPostBack)
            {
                connect.Open();
                String getCL = "SELECT * FROM [Contact_List]";
                SqlDataAdapter da = new SqlDataAdapter(getCL, connect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int x = 0; x < dt.Rows.Count; x++)
                    {
                        string phone = "Phone Number not provided";
                        if (Convert.ToString(dt.Rows[x][3]) != "")
                        {
                            phone = Convert.ToString(dt.Rows[x][3]);
                        }
                        string custInfo = dt.Rows[x][2] + ", " + dt.Rows[x][1] + ";" + phone + ";" + dt.Rows[x][4];
                        ListItem li = new ListItem(custInfo, Convert.ToString(dt.Rows[x][0]));
                        ContactList_CheckList.Items.Insert(x, li);

                    }
                    connect.Close();
                }
                else
                {
                    NoContacts_lbl.Visible = true;
                }
           
            }
        }

        protected void SelectCust_btn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Customer.aspx");
        }

        protected void EmptyList_btn_Click(object sender, EventArgs e)
        {
            connect.Open();
            for (int x = 0; x < ContactList_CheckList.Items.Count; x++)
            {
                String delCL = "DELETE [Contact_List] WHERE Cust_Id= " + ContactList_CheckList.Items[x].Value;
                SqlCommand command = new SqlCommand(delCL, connect);
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.DeleteCommand = new SqlCommand(delCL, connect);
                adapter.DeleteCommand.ExecuteNonQuery();
            }
            Response.Redirect(Request.Url.AbsoluteUri);
        }

        protected void LogOut_btn_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("login.aspx?logOut=true");
        }

        protected void RemoveContact_btn_Click(object sender, EventArgs e)
        {
            string contact = ContactList_CheckList.SelectedValue;
            connect.Open();
            String remove_Contact = "DELETE [Contact_List] WHERE Cust_Id='" + contact + "'";
            SqlCommand command = new SqlCommand(remove_Contact, connect);
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.DeleteCommand = new SqlCommand(remove_Contact, connect);
            adapter.DeleteCommand.ExecuteNonQuery();
            connect.Close();
            Response.Redirect(Request.Url.AbsoluteUri);
        }
    }
}
