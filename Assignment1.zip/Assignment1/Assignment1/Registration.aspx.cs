﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;

namespace Assignment1
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Register_btn_Click(object sender, EventArgs e)
        {
            string firstName = FirstName_txb.Text;
            string lastName = LastName_txb.Text;
            string address = Address_txb.Text;
            string email = Email_txb.Text;
            string phone = Phone_Txb.Text;
            string password = Password_txb.Text;
            string password_Confirm = ConfirmPass_txb.Text;


                bool hasUpper = false;
                bool hasSpecial = false;
                char[] specialCharacters = new char[] {'@','(','?','!','^','*','$',')','?','!'};
                if (password.Length < 6 || password.Length > 12) {
                    Error_Message1.Visible = true;
                    Error_Message1.ForeColor = System.Drawing.Color.Red;
                return;
                }
                foreach (char c in password) {
                    if (char.IsUpper(c)) hasUpper = true;
                    if (specialCharacters.Contains(c)) hasSpecial = true;
                }
                if (hasUpper == false || hasSpecial == false) {
                    Error_Message1.Text = "Password has to contain a an Uppercase and one special Character";
                    Error_Message1.Visible = true;
                    Error_Message1.ForeColor = System.Drawing.Color.Red;
                return;
                }
                if (Check_Email.IsValid == false) {
                    Error_Message2.Visible = true;
                    return;
                }
                if (Agree_chbox.Checked == false) {
                    Error_Message1.Text = "Please agree to our terms of service to proceed";
                    Error_Message1.ForeColor = System.Drawing.Color.Red;
                    Error_Message1.Visible = true;
                    return;
                }

            if (Page.IsValid) {
                SqlCommand command;
                int id = 0;
                SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Management_Software.mdf;Integrated Security=True");
                connect.Open();
                String getUsers = "SELECT Email FROM [User] WHERE Role='" + "client" + "'";
                command = new SqlCommand(getUsers, connect);
                SqlDataAdapter da = new SqlDataAdapter(getUsers, connect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0) {
                    for (int x = 0; x < dt.Rows.Count; x++) {
                        string temp_email = Convert.ToString(dt.Rows[x][0]);
                        temp_email = temp_email.Replace("  ", "");
                        temp_email = temp_email.Replace(" ", "");
                        if  (temp_email == email) {
                            Error_Message1.Text = "User with same email already exists!";
                            Error_Message1.Visible = true;
                            connect.Close();
                            return;
                        }
                    }
                }
                String sqlGetId = "SELECT MAX(Id) FROM [User]";
                command = new SqlCommand(sqlGetId, connect);
                using (SqlDataReader reader = command.ExecuteReader()) {
                    if (reader.Read()) {
                        id = reader.GetInt32(0);
                    }
                }
                id++;
                String sqlInsert = "INSERT INTO [User] " +
                                   "(Id,First_Name,Last_Name,Address,Email,Password,Role,Phone_Number)" +
                                   "VALUES ('"+ id +"','" + firstName + "','" + lastName + "','" + address + 
                                   "','" + email + "','" + password + "','" + "client" + "','" + phone + "') ;";
                command = new SqlCommand(sqlInsert, connect);
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.InsertCommand = new SqlCommand(sqlInsert, connect);
                adapter.InsertCommand.ExecuteNonQuery();

                command.Dispose();
                connect.Close();

                Error_Message1.Text = "";
                Error_Message2.Text = "";
                Email_Notifytxb.Text = "An email has been sent to " + email + ".Please check your email to verify and confirm";
                Success_Panel.Visible = true;
            }
            
        }

        protected void Cancel_btn_Click(object sender, EventArgs e) {
            Response.Redirect("login.aspx");
        }
    }
}