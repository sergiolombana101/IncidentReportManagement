﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;

namespace Assignment1
{
    public partial class ViewSurvey : System.Web.UI.Page
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Management_Software.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (Session["User"] == null)
            {
                Response.Redirect("login.aspx?login=false");
            }
            if (!IsPostBack)
            {
                connect.Open();
                String getCust = "SELECT Id, First_Name, Last_Name, Address, Email, Phone_Number FROM [User] WHERE Role ='" + "client" + "'";
                SqlDataAdapter da = new SqlDataAdapter(getCust, connect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int x = 0; x < dt.Rows.Count; x++)
                    {
                        string firstName = Convert.ToString(dt.Rows[x][1]);
                        string secondName = Convert.ToString(dt.Rows[x][2]);
                        string fullname = secondName.Replace(" ", "") + ", " + firstName.Replace(" ", "");
                        ListItem list = new ListItem(fullname, Convert.ToString(dt.Rows[x][0]));
                        Customer_DropList.Items.Insert(x, list);
                    }
                    CustId_txb.Text = Convert.ToString(dt.Rows[0][0]);
                    String getSurveys = "SELECT Survey_Id, Incident_Id, Response_Time, Technician_Efficiency, Problem_Res, Add_Comments, Contact, Contact_Via FROM [Survey] WHERE Customer_Id = '" + Convert.ToInt32(dt.Rows[0][0]) + "'";
                    da = new SqlDataAdapter(getSurveys, connect);
                    dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int x = 0; x < dt.Rows.Count; x++)
                        {    
                            int count = x;
                            string incident = count + 1 + ". Survey result for incident " + dt.Rows[0][1];
                            ListItem list = new ListItem(incident, Convert.ToString(dt.Rows[count][0]));
                            Survey_DropList.Items.Insert(x, list);
                        }
                    }
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
 
            string surveyIdTemp = Survey_DropList.SelectedValue;
           
            int surveyId = Convert.ToInt32(surveyIdTemp);
            if (surveyId == 0)
            {
                Error_Message.Text = "There are no surveys submitted for this user";
                return;
            }

            connect.Open();
            String getSurvey = "SELECT Response_Time, Technician_Efficiency, Problem_Res, Add_Comments, Contact, Contact_Via FROM [Survey] WHERE Survey_Id = '"+surveyId+"'";
            SqlDataAdapter da = new SqlDataAdapter(getSurvey, connect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0) {
                ResponseTime_lbl.Text = Convert.ToString(dt.Rows[0][0]);
                TechEfficiency_lbl.Text = Convert.ToString(dt.Rows[0][1]);
                ProblemRes_lbl.Text = Convert.ToString(dt.Rows[0][2]);
                AddComments_lbl.Text = Convert.ToString(dt.Rows[0][3]);
                ContactBool_lbl.Text = Convert.ToString(dt.Rows[0][4]);
                ContactMethod_lbl.Text = Convert.ToString(dt.Rows[0][5]);
            }
            connect.Close();
        }

        protected void Home_btn_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminHome.aspx");
        }

        protected void LogOut_btn_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("login.aspx?logOut=true");
        }

        protected void Customer_DropList_SelectedIndexChanged(object sender, EventArgs e)
        {
            Survey_DropList.Items.Clear();
            ResponseTime_lbl.Text = "";
            TechEfficiency_lbl.Text = "";
            ProblemRes_lbl.Text = "";
            AddComments_lbl.Text = "";
            ContactBool_lbl.Text = "";
            ContactMethod_lbl.Text = "";
            string custId = Customer_DropList.SelectedValue;
            String getSurvey_List = "SELECT Survey_Id, Incident_Id FROM [Survey] WHERE Customer_Id = '" + custId + "'";
            connect.Open();
            SqlDataAdapter da = new SqlDataAdapter(getSurvey_List, connect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int x = 0; x < dt.Rows.Count; x++)
                {
                    int count = x;
                    string incident = count + 1 + ". Survey result for incident " + dt.Rows[0][x+1];
                    ListItem list = new ListItem(incident, Convert.ToString(dt.Rows[count][0]));
                    Survey_DropList.Items.Insert(x, list);
                    CustId_txb.Text = Convert.ToString(dt.Rows[0][x]);
                    Error_Message.Text = "";
                }
          
            }
            else {
                string str = "There are no submitted surveys for this user.";
                ListItem list = new ListItem(str, "0");
                Survey_DropList.Items.Insert(0,list);
                String getCust = "SELECT Id FROM [User] WHERE Id='" + custId + "'";
                da = new SqlDataAdapter(getCust, connect);
                dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0) {
                    CustId_txb.Text = Convert.ToString(dt.Rows[0][0]);
                }

            }
    
            connect.Close();

        }
    }
}