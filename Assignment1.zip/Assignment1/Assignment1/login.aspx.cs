﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;

namespace Assignment1
{
    public partial class loginaspx : System.Web.UI.Page
    {
        public static User user;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["login"] == "false") {
                Error_lbl.Text = "You need to login before proceeding";
            }
            if (Request.QueryString["logOut"] == "true")
            {
                user = null;
            }
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Register_btn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }

        protected void Login_btn_Click(object sender, EventArgs e)
        {
            string username = Username_txb.Text;
            string password = Password_txb.Text;
            bool userExist = false;
            if (username == "" || password == "") {
                Error_lbl.Text = "Please fill all the values before proceeding";
                return;
            }
            SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Management_Software.mdf;Integrated Security=True");
            connect.Open();
            String getUser = "SELECT Id FROM [User] WHERE Email='" + username +"'";
            SqlDataAdapter da = new SqlDataAdapter(getUser, connect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count == 0) {
                Error_lbl.Text = "Username not found";
                Password_txb.Text = "";
                connect.Close();
                return;
            }
            userExist = true;
            int id = Convert.ToInt32(dt.Rows[0][0]);
            String getPass = "SELECT Password, Role, First_Name, Last_Name, Email FROM [User] WHERE Id='" + id + "'";
            da = new SqlDataAdapter(getPass, connect);
            dt = new DataTable();
            da.Fill(dt);
            string dbPass = Convert.ToString(dt.Rows[0][0]);
            dbPass = dbPass.Replace(" ", "");
            if (password != dbPass) {
                Error_lbl.Text = "Incorrect Password";
                Password_txb.Text = "";
                connect.Close();
                return;
            }
            string firstName = Convert.ToString(dt.Rows[0][2]);
            firstName = firstName.Replace(" ", "");
            string lastName = Convert.ToString(dt.Rows[0][3]);
            lastName = lastName.Replace(" ", "");
            string email = Convert.ToString(dt.Rows[0][4]);
            email = email.Replace(" ", "");
            string role = Convert.ToString(dt.Rows[0][1]);
            role = role.Replace(" ", "");
            user = new User(id, firstName, lastName, role, email, null, null, null);
            if (role == "client") {
                connect.Close();
                Session["User"] = "customer";
                Response.Redirect("CustomerHome.aspx");
            }
            if (role == "admin") {
                connect.Close();
                Session["User"] = "admin";
                Response.Redirect("AdminHome.aspx");
            }
            if (role == "technician") {
                connect.Close();
                Session["User"] = "technician";
                Response.Redirect("TechHome.aspx");
            }
            Error_lbl.Text = "Login Succesful";

        }
    }
}