﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;

namespace Assignment1
{
    public partial class CreateIncident : System.Web.UI.Page
    {
        string incidentId;
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Management_Software.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (Session["User"] == null)
            {
                Response.Redirect("login.aspx?login=false");
            }
            if (!IsPostBack)
            {
            connect.Open();
            String getCust = "SELECT Id, First_Name, Last_Name FROM [User] WHERE Role ='"+"client"+"'";
            SqlDataAdapter da = new SqlDataAdapter(getCust, connect);
            DataTable dt = new DataTable();
            da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int x = 0; x < dt.Rows.Count; x++)
                    {
                        string firstName = Convert.ToString(dt.Rows[x][1]);
                        string secondName = Convert.ToString(dt.Rows[x][2]);
                        string fullname = secondName.Replace(" ", "") + ", " + firstName.Replace(" ", "");
                        ListItem list = new ListItem(fullname, Convert.ToString(dt.Rows[x][0]));
                        Customer_DropList.Items.Insert(x, list);
                        CustId_txb.Text = Convert.ToString(dt.Rows[0][0]);
                    }
                    connect.Close();
                }
                connect.Open();
                String getIncidents = "SELECT MAX(Incident_Id) FROM[Incident]";
                da = new SqlDataAdapter(getIncidents, connect);
                dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count <= 1)
                {
                    Random random = new Random();
                    incidentId = "";
                    for (int x = 0; x < 4; x++)
                    {
                        incidentId += random.Next(0, 9);
                    }
                }
                else
                {
                    int id = Convert.ToInt32(dt.Rows[0][0]);
                    id++;
                    incidentId = Convert.ToString(id);
                }
                IncidentID_txb.Text = incidentId;
                connect.Close();
            }
            string date = DateTime.Today.ToString("yyyy-MM-dd");
            string time = DateTime.Now.ToString("HH:mm");
            Date_Txb.Text = date + ", " + time;

        }

        protected void Customer_DropList_SelectedIndexChanged(object sender, EventArgs e)
        {
            string value = Customer_DropList.SelectedValue;
            connect.Open();
            String getCust = "SELECT Id FROM [User] WHERE Id = '" + value + "'";
            SqlDataAdapter da = new SqlDataAdapter(getCust, connect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                CustId_txb.Text = Convert.ToString(dt.Rows[0][0]);
            }
            connect.Close();

        }

        protected void Submit_Btn_Click(object sender, EventArgs e)
        {
            if (Description_txb.Text == "") {
                Error_Message.Text = "Please enter a valid description!";
                Error_Message.Visible = true;
                return;
            }
            if (ProductId_txb.Text == "") {
                Error_Message.Text = "Please enter a valid product Id!";
                Error_Message.Visible = true;
                return;
            }
            int productId;
            if (!int.TryParse(ProductId_txb.Text, out productId)) {
                Error_Message.Text = "Please enter a number for product Id";
                Error_Message.Visible = true;
                return;
            }
            int custId = Convert.ToInt32(CustId_txb.Text);
            string status = Status_dropList.SelectedValue;
            productId = Convert.ToInt32(ProductId_txb.Text);
            string dateTemp = Date_Txb.Text;
            string description = Description_txb.Text;
            dateTemp = dateTemp.Replace(", ", " ");
            DateTime date = DateTime.Parse(dateTemp);
            string format = "dd-MM-yyyy HH:mm";
            connect.Open();
            String insertIncident = "INSERT INTO [Incident] " +
                                "(Incident_Id, Cust_Id, Product, Status, Date, Description)" +
                                "VALUES('" + IncidentID_txb.Text + "','" + custId + "','" + productId + "','" + status + "','" + date + "','" + description + "');";
            SqlCommand command = new SqlCommand(insertIncident, connect);
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.InsertCommand = new SqlCommand(insertIncident, connect);
            adapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            connect.Close();

            Error_Message.Text = "Incident succesfully submited";
            Error_Message.ForeColor = System.Drawing.Color.Green;
            Error_Message.Visible = true;

        }

        protected void LogOut_Btn_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("login.aspx?logOut=true");
        }
    }
}