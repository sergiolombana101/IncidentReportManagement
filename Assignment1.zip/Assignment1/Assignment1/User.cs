﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web;
using System.Data;

namespace Assignment1
{
    public class User
    {
        private int id;
        private string firstName;
        private string lastName;
        private string role;
        private string email;
        private string question;
        private string answer;
        private string position;

        public User(int id, string firstName, string lastName, string role, string email, string question, string answer, string position) {
            this.id = id;
            this.firstName = firstName;
            this.lastName = lastName;
            this.role = role;
            this.email = email;
            this.question = question;
            this.answer = answer;
            this.position = position;
        }

        public int getId() { return id; }
        public string getFN() { return firstName; }
        public string getLN() { return lastName; }
        public string getRole() { return role; }
        public string getMail() { return email; }
        public string getQuestion() { return question; }
        public string getAnswer() { return answer; }
        public string getPosition() { return position; }
        public void update() {
            SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Management_Software.mdf;Integrated Security=True");
            connect.Open();
            String getInfo = "SELECT First_Name, Last_Name, Email, Role, Secret_Q, Secret_A, Position FROM [User] WHERE Id='"+this.id+"'";
            SqlDataAdapter da = new SqlDataAdapter(getInfo, connect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            this.firstName = Convert.ToString(dt.Rows[0][0]);
            this.lastName = Convert.ToString(dt.Rows[0][1]);
            this.email = Convert.ToString(dt.Rows[0][2]);
            this.role = Convert.ToString(dt.Rows[0][3]);
            this.question = Convert.ToString(dt.Rows[0][4]);
            this.answer = Convert.ToString(dt.Rows[0][5]);
            this.position = Convert.ToString(dt.Rows[0][6]);
            connect.Close();
        }
    }
}