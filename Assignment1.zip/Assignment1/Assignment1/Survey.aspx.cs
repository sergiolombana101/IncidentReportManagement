﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;

namespace Assignment1
{
    public partial class Survey : System.Web.UI.Page
    {
        User user = loginaspx.user;
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Management_Software.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (Session["User"] == null)
            {
                Response.Redirect("login.aspx?login=false");
            }
            if (!IsPostBack) {
                Cust_Idtxb.Text = Convert.ToString(user.getId());
                connect.Open();
                String getIncidents = "SELECT Incident_Id, Product, Status, Description FROM Incident WHERE Cust_Id='" + user.getId() + "'";
                SqlDataAdapter da = new SqlDataAdapter(getIncidents, connect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0) {
                    for (int x = 0; x < dt.Rows.Count; x++)
                    {
                        int count = x;
                        string incident = count + 1 + ". Incident for Product " + dt.Rows[0][1]+", "+dt.Rows[0][2]+" - "+dt.Rows[0][3];
                        ListItem list = new ListItem(incident, Convert.ToString(dt.Rows[count][0]));
                        Incident_DropList.Items.Insert(x, list);
                    }
                    connect.Close();
                }
            }

        }

        protected void Submit_btn_Click(object sender, EventArgs e)
        {
            if (ResponseT_Radio.SelectedIndex == -1 ||
               TechnicianE_Radio.SelectedIndex == -1 ||
               ProblemR_Radio.SelectedIndex == -1||ContactVia_RadioList.SelectedIndex == -1)
            {
                Error_Message.Visible = true;
            }
            else
            {
                String getSurveys = "SELECT MAX(Survey_Id) FROM[Survey]";
                SqlDataAdapter da = new SqlDataAdapter(getSurveys, connect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                string surveyId = "";
                if (dt.Rows.Count <= 1)
                {
                    Random random = new Random();
                    for (int x = 0; x < 4; x++)
                    {
                        surveyId += random.Next(0, 9);
                    }
                }
                else {
                    int id = Convert.ToInt32(dt.Rows[0][0]);
                    id++;
                    surveyId = Convert.ToString(id);
                }
                    string incidentId = Incident_DropList.SelectedValue;
                if (incidentId == "") {
                    Error_Message.Text = "Please select an incident before proceeding!";
                    Error_Message.Visible = true;
                    return;
                }
                    string responseT = ResponseT_Radio.SelectedValue;
                    responseT = responseT.Replace("_", " ");
                    string technicianE = TechnicianE_Radio.SelectedValue;
                    technicianE = technicianE.Replace("_", " ");
                    string problemR = ProblemR_Radio.SelectedValue;
                    problemR = problemR.Replace("_", " ");
                    string comments = Comments_txb.Text;
                    comments = comments.Replace("  ", "");
                    string contact = "No";
                    string contactVia = ContactVia_RadioList.SelectedValue;
                    if (Contact_check.Checked) {
                        contact = "Yes";
                    }
                    connect.Open();
                    String insertSurvey = "INSERT INTO [Survey]" +
                                      "(Survey_Id, Incident_Id, Customer_Id, Response_Time, Technician_Efficiency, Problem_Res, Add_Comments, Contact, Contact_Via)" +
                                      "VALUES('" + surveyId + "','" + incidentId + "','" + user.getId() + "','" + responseT + "','" + technicianE + "','" + problemR + "','" + comments + "','"+contact+"','" + contactVia + "');";
                    SqlCommand command = new SqlCommand(insertSurvey, connect);
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    adapter.InsertCommand = new SqlCommand(insertSurvey, connect);
                    adapter.InsertCommand.ExecuteNonQuery();

                    command.Dispose();
                    connect.Close();

                    Error_Message.Text = "Survey succesfully submited";
                    Error_Message.ForeColor = System.Drawing.Color.Green;
                    Error_Message.Visible = true;

            }
        }

        protected void Home_Btn_Click(object sender, EventArgs e)
        {
            Response.Redirect("CustomerHome.aspx");
        }

        protected void LogOut_btn_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("login.aspx?logOut=true");
        }
    }
}