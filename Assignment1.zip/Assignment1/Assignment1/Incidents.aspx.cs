﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;

namespace Assignment1
{
    public partial class Incidents : System.Web.UI.Page
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Management_Software.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (Session["User"] == null)
            {
                Response.Redirect("login.aspx?login=false");
            }
            if (!IsPostBack)
            {
                connect.Open();
                String getCust = "SELECT Id, First_Name, Last_Name FROM [User] WHERE Role ='" + "client" + "'";
                SqlDataAdapter da = new SqlDataAdapter(getCust, connect);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int x = 0; x < dt.Rows.Count; x++)
                    {
                        string firstName = Convert.ToString(dt.Rows[x][1]);
                        string secondName = Convert.ToString(dt.Rows[x][2]);
                        string fullname = secondName.Replace(" ", "") + ", " + firstName.Replace(" ", "");
                        ListItem list = new ListItem(fullname, Convert.ToString(dt.Rows[x][0]));
                        Customer_DropList.Items.Insert(x, list);
                    }
                    String getIncidents = "SELECT Incident_Id, Product, Status, Date, Description FROM [Incident] WHERE Cust_Id = '" +   Convert.ToInt32(dt.Rows[0][0]) + "'";
                    da = new SqlDataAdapter(getIncidents, connect);
                    dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0) {
                        for (int x = 0; x < dt.Rows.Count; x++) {
                            string productId = Convert.ToString(dt.Rows[x][1]);
                            string status = Convert.ToString(dt.Rows[x][2]);
                            string description = Convert.ToString(dt.Rows[x][4]);
                            DateTime date = Convert.ToDateTime(dt.Rows[x][3]);
                            int count = x;
                            string incident = count+1 + ". Incident for Product "+ productId.Replace(" ","")+", "+status.Replace(" ","")+", "+ date.Month + "/"+date.Day+"/"+date.Year+" - "+description.Replace(" ","");
                            ListItem list = new ListItem(incident, Convert.ToString(dt.Rows[count][0]));
                            Incident_DropList.Items.Insert(x, list);
                        }
                    }
                    connect.Close();
                }
            }
        }

        protected void Customer_DropList_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            int custId = Convert.ToInt32(Customer_DropList.SelectedValue);
            String getIncidents = "SELECT Incident_Id, Product, Status, Date, Description FROM [Incident] WHERE Cust_Id = '" + custId + "'";
            SqlDataAdapter da = new SqlDataAdapter(getIncidents, connect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Incident_DropList.Items.Clear();
                for (int x = 0; x < dt.Rows.Count; x++)
                {
                    string productId = Convert.ToString(dt.Rows[x][1]);
                    string status = Convert.ToString(dt.Rows[x][2]);
                    string description = Convert.ToString(dt.Rows[x][4]);
                    DateTime date = Convert.ToDateTime(dt.Rows[x][3]);
                    int count = x;
                    string incident = count + 1 + ". Incident for Product " + productId.Replace(" ", "") + ", " + status.Replace(" ", "") + ", " + date.Month + "/" + date.Day + "/" + date.Year + " - " + description.Replace(" ", "");
                    ListItem list = new ListItem(incident, Convert.ToString(dt.Rows[count][0]));
                    Incident_DropList.Items.Insert(x, list);
                }
            }
            connect.Close();
        }

        protected void Retrieve_btn_Click(object sender, EventArgs e)
        {
            int incidentId = Convert.ToInt32(Incident_DropList.SelectedValue);
            String getIncident = "SELECT Cust_Id, Status, Date, Description FROM[Incident] WHERE Incident_Id = '" + incidentId + "'";
            connect.Open();
            SqlDataAdapter da = new SqlDataAdapter(getIncident, connect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0) {
                IncidentId_lbl.Text = Convert.ToString(incidentId);
                CustId_lbl.Text = Convert.ToString(dt.Rows[0][0]);
                Status_lbl.Text = Convert.ToString(dt.Rows[0][1]);
                Date_lbl.Text = Convert.ToString(dt.Rows[0][2]);
                Description_txt.Text = Convert.ToString(dt.Rows[0][3]);
            }
            connect.Close();
        }

        protected void LogOut_btn_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("login.aspx?logOut=true");
        }

        protected void Home_Btn_Click(object sender, EventArgs e)
        {
            Response.Redirect("TechHome.aspx");
        }
    }
}