﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;

namespace Assignment1
{
    public partial class ProfilePage : System.Web.UI.Page
    {
        User user = loginaspx.user;
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (!IsPostBack)
            {
                if (Session["User"] == null)
                {
                    Response.Redirect("login.aspx?login=false");
                }
                string fullname = user.getFN().Replace(" ", "") + " " + user.getLN().Replace(" ", "");
                Profile_Nametxb.Text = fullname;
                Username_txb.Text = user.getMail();
                First_Nametxb.Text = user.getFN();
                Last_Nametxb.Text = user.getLN();
                if (user.getPosition() != null)
                {
                    Position_Txb.Text = user.getPosition();
                }
                if (user.getQuestion() != null)
                {
                    Question_Dropdown.SelectedValue = user.getQuestion();
                }
                if (user.getAnswer() != null)
                {
                    Secret_Atxb.Text = user.getAnswer();
                }
                Email_txb.Text = user.getMail();
            }

        }

        protected void Update_Btn_Click(object sender, EventArgs e)
        {
            string username = Username_txb.Text;
            string password = Password_txb.Text;
            string firstName = First_Nametxb.Text;
            string lastName = Last_Nametxb.Text;
            string position = Position_Txb.Text;
            string secretQ = Question_Dropdown.SelectedValue;
            string secretA = Secret_Atxb.Text;
            string email = Email_txb.Text;
            string[] values = new string[] { username, firstName, lastName, secretQ, secretA, email };
            foreach (string value in values) {
                if (value == "") {
                    Error_Message.Text = "Please fill all the required boxes (*) before updating";
                    return;
                }
            }
            bool hasUpper = false;
            bool hasSpecial = false;
            char[] specialCharacters = new char[] { '@', '(', '?', '!', '^', '*', '$', ')', '?', '!' };
            if (password != "")
            {
                if (password.Length < 6 || password.Length > 12)
                {
                    Error_Message.Text = "Password has to be 6 to 12 characters long";
                    return;
                }
                foreach (char c in password)
                {
                    if (char.IsUpper(c)) hasUpper = true;
                    if (specialCharacters.Contains(c)) hasSpecial = true;
                }
                if (hasUpper == false || hasSpecial == false)
                {
                    Error_Message.Text = "Password has to contain a an Uppercase and one special Character";
                    return;
                }
            }
            SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Management_Software.mdf;Integrated Security=True");
            connect.Open();
            String getPrev_Pass = "SELECT Password FROM [User] WHERE Id='" + user.getId() + "'";
            SqlDataAdapter da = new SqlDataAdapter(getPrev_Pass, connect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            string prev_pass = "";
            if (dt.Rows.Count > 0) {
                prev_pass = Convert.ToString(dt.Rows[0][0]);
            }
            if (password == "") {
                password = prev_pass.Replace("  ","");
            }
            String update = "UPDATE [User] " +
                            "SET First_Name= '" + firstName + "', Last_Name='"+lastName+"',Password='"+password+
                            "',Secret_Q='"+secretQ+"',Secret_A='"+secretA+"',Position='"+position+"' WHERE Id='"+user.getId()+  "'";
            SqlCommand command = new SqlCommand(update, connect);
            SqlDataAdapter ad = new SqlDataAdapter();
            ad.InsertCommand = new SqlCommand(update, connect);
            ad.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            connect.Close();
            user.update();
            Error_Message.Text = "Values Updated Succesfully";
            Error_Message.ForeColor = System.Drawing.Color.Green;
            return;
        }

        protected void LogOut_Btn_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("login.aspx?logOut=true");
        }
    }
}